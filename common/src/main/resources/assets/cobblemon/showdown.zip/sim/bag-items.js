"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var bag_items_exports = {};
__export(bag_items_exports, {
  additionalItemEffects: () => additionalItemEffects,
  itemHealAmounts: () => itemHealAmounts
});
module.exports = __toCommonJS(bag_items_exports);
const itemHealAmounts = /* @__PURE__ */ new Map([
  ["potion", (_) => 20],
  ["super-potion", (_) => 60],
  ["hyper-potion", (_) => 120],
  ["max-potion", (pokemon) => pokemon.maxhp],
  ["full-restore", (pokemon) => pokemon.maxhp]
]);
const additionalItemEffects = /* @__PURE__ */ new Map([
  ["full-restore", (pokemon) => pokemon.clearStatus()]
]);
//# sourceMappingURL=bag-items.js.map
