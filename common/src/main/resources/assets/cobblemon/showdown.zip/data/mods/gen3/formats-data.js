"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var formats_data_exports = {};
__export(formats_data_exports, {
  FormatsData: () => FormatsData
});
module.exports = __toCommonJS(formats_data_exports);
const FormatsData = {
  bulbasaur: {
    tier: "LC"
  },
  ivysaur: {
    tier: "NFE"
  },
  venusaur: {
    tier: "UUBL"
  },
  charmander: {
    tier: "LC"
  },
  charmeleon: {
    tier: "NFE"
  },
  charizard: {
    tier: "OU"
  },
  squirtle: {
    tier: "LC"
  },
  wartortle: {
    tier: "NFE"
  },
  blastoise: {
    tier: "UU"
  },
  caterpie: {
    tier: "LC"
  },
  metapod: {
    tier: "NFE"
  },
  butterfree: {
    tier: "PU"
  },
  weedle: {
    tier: "LC"
  },
  kakuna: {
    tier: "NFE"
  },
  beedrill: {
    tier: "PU"
  },
  pidgey: {
    tier: "LC"
  },
  pidgeotto: {
    tier: "NFE"
  },
  pidgeot: {
    tier: "NU"
  },
  rattata: {
    tier: "LC"
  },
  raticate: {
    tier: "NU"
  },
  spearow: {
    tier: "LC"
  },
  fearow: {
    tier: "UU"
  },
  ekans: {
    tier: "LC"
  },
  arbok: {
    tier: "PU"
  },
  pichu: {
    tier: "LC"
  },
  pikachu: {
    tier: "NU"
  },
  raichu: {
    tier: "UU"
  },
  sandshrew: {
    tier: "LC"
  },
  sandslash: {
    tier: "UU"
  },
  nidoranf: {
    tier: "LC"
  },
  nidorina: {
    tier: "NFE"
  },
  nidoqueen: {
    tier: "UU"
  },
  nidoranm: {
    tier: "LC"
  },
  nidorino: {
    tier: "NFE"
  },
  nidoking: {
    tier: "UU"
  },
  cleffa: {
    tier: "LC"
  },
  clefairy: {
    tier: "NFE"
  },
  clefable: {
    tier: "UU"
  },
  vulpix: {
    tier: "LC"
  },
  ninetales: {
    tier: "UU"
  },
  igglybuff: {
    tier: "LC"
  },
  jigglypuff: {
    tier: "NFE"
  },
  wigglytuff: {
    tier: "PU"
  },
  zubat: {
    tier: "LC"
  },
  golbat: {
    tier: "NU"
  },
  crobat: {
    tier: "UUBL"
  },
  oddish: {
    tier: "LC"
  },
  gloom: {
    tier: "NFE"
  },
  vileplume: {
    tier: "UU"
  },
  bellossom: {
    tier: "NU"
  },
  paras: {
    tier: "LC"
  },
  parasect: {
    tier: "PU"
  },
  venonat: {
    tier: "LC"
  },
  venomoth: {
    tier: "NU"
  },
  diglett: {
    tier: "NU"
  },
  dugtrio: {
    tier: "OU"
  },
  meowth: {
    tier: "LC"
  },
  persian: {
    tier: "UU"
  },
  psyduck: {
    tier: "LC"
  },
  golduck: {
    tier: "UU"
  },
  mankey: {
    tier: "LC"
  },
  primeape: {
    tier: "UU"
  },
  growlithe: {
    tier: "LC"
  },
  arcanine: {
    tier: "UU"
  },
  poliwag: {
    tier: "LC"
  },
  poliwhirl: {
    tier: "NFE"
  },
  poliwrath: {
    tier: "UU"
  },
  politoed: {
    tier: "UU"
  },
  abra: {
    tier: "LC"
  },
  kadabra: {
    tier: "UUBL"
  },
  alakazam: {
    tier: "UUBL"
  },
  machop: {
    tier: "LC"
  },
  machoke: {
    tier: "PUBL"
  },
  machamp: {
    tier: "UUBL"
  },
  bellsprout: {
    tier: "LC"
  },
  weepinbell: {
    tier: "NFE"
  },
  victreebel: {
    tier: "UU"
  },
  tentacool: {
    tier: "LC"
  },
  tentacruel: {
    tier: "UU"
  },
  geodude: {
    tier: "LC"
  },
  graveler: {
    tier: "NFE"
  },
  golem: {
    tier: "UU"
  },
  ponyta: {
    tier: "LC"
  },
  rapidash: {
    tier: "UU"
  },
  slowpoke: {
    tier: "LC"
  },
  slowbro: {
    tier: "UUBL"
  },
  slowking: {
    tier: "UU"
  },
  magnemite: {
    tier: "LC"
  },
  magneton: {
    tier: "OU"
  },
  farfetchd: {
    tier: "PU"
  },
  doduo: {
    tier: "LC"
  },
  dodrio: {
    tier: "UUBL"
  },
  seel: {
    tier: "LC"
  },
  dewgong: {
    tier: "NU"
  },
  grimer: {
    tier: "LC"
  },
  muk: {
    tier: "UU"
  },
  shellder: {
    tier: "LC"
  },
  cloyster: {
    tier: "OU"
  },
  gastly: {
    tier: "LC"
  },
  haunter: {
    tier: "NU"
  },
  gengar: {
    tier: "OU"
  },
  onix: {
    tier: "LC"
  },
  steelix: {
    tier: "UUBL"
  },
  drowzee: {
    tier: "LC"
  },
  hypno: {
    tier: "UU"
  },
  krabby: {
    tier: "LC"
  },
  kingler: {
    tier: "PU"
  },
  voltorb: {
    tier: "LC"
  },
  electrode: {
    tier: "UU"
  },
  exeggcute: {
    tier: "LC"
  },
  exeggutor: {
    tier: "UUBL"
  },
  cubone: {
    tier: "LC"
  },
  marowak: {
    tier: "UUBL"
  },
  tyrogue: {
    tier: "LC"
  },
  hitmonlee: {
    tier: "UU"
  },
  hitmonchan: {
    tier: "NU"
  },
  hitmontop: {
    tier: "UU"
  },
  lickitung: {
    tier: "PU"
  },
  koffing: {
    tier: "LC"
  },
  weezing: {
    tier: "UUBL"
  },
  rhyhorn: {
    tier: "LC"
  },
  rhydon: {
    tier: "UUBL"
  },
  chansey: {
    tier: "UUBL"
  },
  blissey: {
    tier: "OU"
  },
  tangela: {
    tier: "PU"
  },
  kangaskhan: {
    tier: "UU"
  },
  horsea: {
    tier: "LC"
  },
  seadra: {
    tier: "NFE"
  },
  kingdra: {
    tier: "UUBL"
  },
  goldeen: {
    tier: "LC"
  },
  seaking: {
    tier: "PU"
  },
  staryu: {
    tier: "LC"
  },
  starmie: {
    tier: "OU"
  },
  mrmime: {
    tier: "UU"
  },
  scyther: {
    tier: "UU"
  },
  scizor: {
    tier: "UUBL"
  },
  smoochum: {
    tier: "LC"
  },
  jynx: {
    tier: "UUBL"
  },
  elekid: {
    tier: "LC"
  },
  electabuzz: {
    tier: "UU"
  },
  magby: {
    tier: "LC"
  },
  magmar: {
    tier: "UU"
  },
  pinsir: {
    tier: "UU"
  },
  tauros: {
    tier: "UUBL"
  },
  magikarp: {
    tier: "LC"
  },
  gyarados: {
    tier: "OU"
  },
  lapras: {
    tier: "UUBL"
  },
  ditto: {
    tier: "PU"
  },
  eevee: {
    tier: "LC"
  },
  vaporeon: {
    tier: "UUBL"
  },
  jolteon: {
    tier: "OU"
  },
  flareon: {
    tier: "NU"
  },
  espeon: {
    tier: "UUBL"
  },
  umbreon: {
    tier: "UUBL"
  },
  porygon: {
    tier: "LC"
  },
  porygon2: {
    tier: "UUBL"
  },
  omanyte: {
    tier: "LC"
  },
  omastar: {
    tier: "UU"
  },
  kabuto: {
    tier: "LC"
  },
  kabutops: {
    tier: "UU"
  },
  aerodactyl: {
    tier: "OU"
  },
  snorlax: {
    tier: "OU"
  },
  articuno: {
    tier: "UUBL"
  },
  zapdos: {
    tier: "OU"
  },
  moltres: {
    tier: "OU"
  },
  dratini: {
    tier: "LC"
  },
  dragonair: {
    tier: "NFE"
  },
  dragonite: {
    tier: "UUBL"
  },
  mewtwo: {
    tier: "Uber"
  },
  mew: {
    tier: "Uber"
  },
  chikorita: {
    tier: "LC"
  },
  bayleef: {
    tier: "NFE"
  },
  meganium: {
    tier: "UU"
  },
  cyndaquil: {
    tier: "LC"
  },
  quilava: {
    tier: "NFE"
  },
  typhlosion: {
    tier: "UUBL"
  },
  totodile: {
    tier: "LC"
  },
  croconaw: {
    tier: "NFE"
  },
  feraligatr: {
    tier: "UU"
  },
  sentret: {
    tier: "LC"
  },
  furret: {
    tier: "PU"
  },
  hoothoot: {
    tier: "LC"
  },
  noctowl: {
    tier: "PU"
  },
  ledyba: {
    tier: "LC"
  },
  ledian: {
    tier: "PU"
  },
  spinarak: {
    tier: "LC"
  },
  ariados: {
    tier: "PU"
  },
  chinchou: {
    tier: "LC"
  },
  lanturn: {
    tier: "UU"
  },
  togepi: {
    tier: "LC"
  },
  togetic: {
    tier: "PU"
  },
  natu: {
    tier: "LC"
  },
  xatu: {
    tier: "UU"
  },
  mareep: {
    tier: "LC"
  },
  flaaffy: {
    tier: "NFE"
  },
  ampharos: {
    tier: "UU"
  },
  azurill: {
    tier: "LC"
  },
  marill: {
    tier: "NFE"
  },
  azumarill: {
    tier: "UU"
  },
  sudowoodo: {
    tier: "NU"
  },
  hoppip: {
    tier: "LC"
  },
  skiploom: {
    tier: "NFE"
  },
  jumpluff: {
    tier: "UUBL"
  },
  aipom: {
    tier: "PU"
  },
  sunkern: {
    tier: "LC"
  },
  sunflora: {
    tier: "PU"
  },
  yanma: {
    tier: "PU"
  },
  wooper: {
    tier: "LC"
  },
  quagsire: {
    tier: "UU"
  },
  murkrow: {
    tier: "NU"
  },
  misdreavus: {
    tier: "UU"
  },
  unown: {
    tier: "PU"
  },
  wynaut: {
    tier: "Uber"
  },
  wobbuffet: {
    tier: "Uber"
  },
  girafarig: {
    tier: "UU"
  },
  pineco: {
    tier: "LC"
  },
  forretress: {
    tier: "OU"
  },
  dunsparce: {
    tier: "PUBL"
  },
  gligar: {
    tier: "UU"
  },
  snubbull: {
    tier: "LC"
  },
  granbull: {
    tier: "UU"
  },
  qwilfish: {
    tier: "UU"
  },
  shuckle: {
    tier: "PU"
  },
  heracross: {
    tier: "OU"
  },
  sneasel: {
    tier: "UU"
  },
  teddiursa: {
    tier: "LC"
  },
  ursaring: {
    tier: "UUBL"
  },
  slugma: {
    tier: "LC"
  },
  magcargo: {
    tier: "PU"
  },
  swinub: {
    tier: "LC"
  },
  piloswine: {
    tier: "PU"
  },
  corsola: {
    tier: "PU"
  },
  remoraid: {
    tier: "LC"
  },
  octillery: {
    tier: "NU"
  },
  delibird: {
    tier: "PU"
  },
  mantine: {
    tier: "UU"
  },
  skarmory: {
    tier: "OU"
  },
  houndour: {
    tier: "LC"
  },
  houndoom: {
    tier: "UUBL"
  },
  phanpy: {
    tier: "LC"
  },
  donphan: {
    tier: "UUBL"
  },
  stantler: {
    tier: "UU"
  },
  smeargle: {
    tier: "UUBL"
  },
  miltank: {
    tier: "UUBL"
  },
  raikou: {
    tier: "UUBL"
  },
  entei: {
    tier: "UUBL"
  },
  suicune: {
    tier: "OU"
  },
  larvitar: {
    tier: "LC"
  },
  pupitar: {
    tier: "NU"
  },
  tyranitar: {
    tier: "OU"
  },
  lugia: {
    tier: "Uber"
  },
  hooh: {
    tier: "Uber"
  },
  celebi: {
    tier: "OU"
  },
  treecko: {
    tier: "LC"
  },
  grovyle: {
    tier: "NFE"
  },
  sceptile: {
    tier: "UUBL"
  },
  torchic: {
    tier: "LC"
  },
  combusken: {
    tier: "NFE"
  },
  blaziken: {
    tier: "UUBL"
  },
  mudkip: {
    tier: "LC"
  },
  marshtomp: {
    tier: "NFE"
  },
  swampert: {
    tier: "OU"
  },
  poochyena: {
    tier: "LC"
  },
  mightyena: {
    tier: "PU"
  },
  zigzagoon: {
    tier: "LC"
  },
  linoone: {
    tier: "UU"
  },
  wurmple: {
    tier: "LC"
  },
  silcoon: {
    tier: "NFE"
  },
  beautifly: {
    tier: "PU"
  },
  cascoon: {
    tier: "NFE"
  },
  dustox: {
    tier: "PU"
  },
  lotad: {
    tier: "LC"
  },
  lombre: {
    tier: "NFE"
  },
  ludicolo: {
    tier: "UUBL"
  },
  seedot: {
    tier: "LC"
  },
  nuzleaf: {
    tier: "NFE"
  },
  shiftry: {
    tier: "UU"
  },
  taillow: {
    tier: "LC"
  },
  swellow: {
    tier: "UUBL"
  },
  wingull: {
    tier: "LC"
  },
  pelipper: {
    tier: "NU"
  },
  ralts: {
    tier: "LC"
  },
  kirlia: {
    tier: "NFE"
  },
  gardevoir: {
    tier: "UUBL"
  },
  surskit: {
    tier: "LC"
  },
  masquerain: {
    tier: "PU"
  },
  shroomish: {
    tier: "LC"
  },
  breloom: {
    tier: "OU"
  },
  slakoth: {
    tier: "LC"
  },
  vigoroth: {
    tier: "NU"
  },
  slaking: {
    tier: "UUBL"
  },
  nincada: {
    tier: "LC"
  },
  ninjask: {
    tier: "UU"
  },
  shedinja: {
    tier: "PU"
  },
  whismur: {
    tier: "LC"
  },
  loudred: {
    tier: "NFE"
  },
  exploud: {
    tier: "UU"
  },
  makuhita: {
    tier: "LC"
  },
  hariyama: {
    tier: "UUBL"
  },
  nosepass: {
    tier: "PU"
  },
  skitty: {
    tier: "LC"
  },
  delcatty: {
    tier: "PU"
  },
  sableye: {
    tier: "NU"
  },
  mawile: {
    tier: "PU"
  },
  aron: {
    tier: "LC"
  },
  lairon: {
    tier: "NFE"
  },
  aggron: {
    tier: "UU"
  },
  meditite: {
    tier: "LC"
  },
  medicham: {
    tier: "UUBL"
  },
  electrike: {
    tier: "LC"
  },
  manectric: {
    tier: "UU"
  },
  plusle: {
    tier: "NU"
  },
  minun: {
    tier: "PU"
  },
  volbeat: {
    tier: "PU"
  },
  illumise: {
    tier: "PU"
  },
  roselia: {
    tier: "NU"
  },
  gulpin: {
    tier: "LC"
  },
  swalot: {
    tier: "PU"
  },
  carvanha: {
    tier: "LC"
  },
  sharpedo: {
    tier: "UU"
  },
  wailmer: {
    tier: "LC"
  },
  wailord: {
    tier: "NU"
  },
  numel: {
    tier: "LC"
  },
  camerupt: {
    tier: "UU"
  },
  torkoal: {
    tier: "NU"
  },
  spoink: {
    tier: "LC"
  },
  grumpig: {
    tier: "UU"
  },
  spinda: {
    tier: "PU"
  },
  trapinch: {
    tier: "LC"
  },
  vibrava: {
    tier: "NFE"
  },
  flygon: {
    tier: "OU"
  },
  cacnea: {
    tier: "LC"
  },
  cacturne: {
    tier: "NU"
  },
  swablu: {
    tier: "LC"
  },
  altaria: {
    tier: "UU"
  },
  zangoose: {
    tier: "UUBL"
  },
  seviper: {
    tier: "PU"
  },
  lunatone: {
    tier: "UU"
  },
  solrock: {
    tier: "UU"
  },
  barboach: {
    tier: "LC"
  },
  whiscash: {
    tier: "NU"
  },
  corphish: {
    tier: "LC"
  },
  crawdaunt: {
    tier: "NU"
  },
  baltoy: {
    tier: "LC"
  },
  claydol: {
    tier: "OU"
  },
  lileep: {
    tier: "LC"
  },
  cradily: {
    tier: "UU"
  },
  anorith: {
    tier: "LC"
  },
  armaldo: {
    tier: "UUBL"
  },
  feebas: {
    tier: "LC"
  },
  milotic: {
    tier: "OU"
  },
  castform: {
    tier: "PU"
  },
  castformsunny: {
    tier: "PU"
  },
  castformrainy: {
    tier: "PU"
  },
  castformsnowy: {
    tier: "PU"
  },
  kecleon: {
    tier: "NU"
  },
  shuppet: {
    tier: "LC"
  },
  banette: {
    tier: "UU"
  },
  duskull: {
    tier: "LC"
  },
  dusclops: {
    tier: "UUBL"
  },
  tropius: {
    tier: "PU"
  },
  chimecho: {
    tier: "NU"
  },
  absol: {
    tier: "UU"
  },
  snorunt: {
    tier: "LC"
  },
  glalie: {
    tier: "NU"
  },
  spheal: {
    tier: "LC"
  },
  sealeo: {
    tier: "NFE"
  },
  walrein: {
    tier: "UU"
  },
  clamperl: {
    tier: "LC"
  },
  huntail: {
    tier: "NU"
  },
  gorebyss: {
    tier: "UU"
  },
  relicanth: {
    tier: "NU"
  },
  luvdisc: {
    tier: "PU"
  },
  bagon: {
    tier: "LC"
  },
  shelgon: {
    tier: "NFE"
  },
  salamence: {
    tier: "OU"
  },
  beldum: {
    tier: "LC"
  },
  metang: {
    tier: "NU"
  },
  metagross: {
    tier: "OU"
  },
  regirock: {
    tier: "UUBL"
  },
  regice: {
    tier: "UUBL"
  },
  registeel: {
    tier: "UUBL"
  },
  latias: {
    tier: "Uber"
  },
  latios: {
    tier: "Uber"
  },
  kyogre: {
    tier: "Uber"
  },
  groudon: {
    tier: "Uber"
  },
  rayquaza: {
    tier: "Uber"
  },
  jirachi: {
    tier: "OU"
  },
  deoxys: {
    tier: "Uber"
  },
  deoxysattack: {
    tier: "Uber"
  },
  deoxysdefense: {
    tier: "Uber"
  },
  deoxysspeed: {
    tier: "Uber"
  }
};
//# sourceMappingURL=formats-data.js.map
